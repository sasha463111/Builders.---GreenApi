// Alias stub - provides compatibility layer for DOM selectors
(function() {
  'use strict';
  
  // This file ensures compatibility between different selector patterns
  // No-op in unified version as we use consistent selectors
  console.log('[Builders] Alias loaded');
})();

