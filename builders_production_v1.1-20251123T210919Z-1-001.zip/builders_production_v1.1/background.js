// Background service worker for context menu
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "openBuilders",
    title: "פתח ב-Builders",
    contexts: ["selection"]
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "openBuilders" && info.selectionText) {
    // The popup will handle the phone number when opened
    chrome.action.openPopup();
  }
});

