function unique(arr){ return Array.from(new Set(arr)).filter(Boolean); }

function grabPotentialPhones(){
  const results = [];

  // 1) elements that declare telephone
  document.querySelectorAll('[data-tid*="phone" i],[data-tid="telephone"], [data-testid*="phone" i], [href^="tel:"], a[href*="tel:"]').forEach(el=>{
    const t = (el.textContent||"").trim() || (el.getAttribute('href')||"").replace(/^tel:/i, '').trim();
    if(t) results.push(t);
  });

  // 2) Look for phone numbers in href attributes
  document.querySelectorAll('a[href*="tel:"], a[href*="phone"]').forEach(el=>{
    const href = el.getAttribute('href') || '';
    const telMatch = href.match(/tel:([+\d\s\-()]+)/i);
    if(telMatch && telMatch[1]) {
      results.push(telMatch[1].trim());
    }
  });

  // 3) scan whole body for common phone patterns (Israeli + international)
  // Improved regex to catch more patterns: 050-123-4567, 050 123 4567, 0501234567, +972-50-123-4567, etc.
  const rx = /(\+?\d{1,4}[-.\s]?)?(\(?\d{1,4}\)?[-.\s]?)?(0\d{1,2}[-.\s]?)?\d{2,3}[-.\s]?\d{3,4}[-.\s]?\d{3,4}/g;
  const text = document.body.innerText || document.body.textContent || "";
  let m;
  while((m = rx.exec(text))){
    if(m[0] && m[0].replace(/[^\d+]/g, '').length >= 8) { // At least 8 digits
      results.push(m[0]);
    }
  }

  // Normalize
  const cleaned = results.map(s => {
    let x = (""+s).replace(/[^\d+]/g,"");
    if(x.startsWith("0")) x = x.replace(/^0/,"+972");
    if(/^972/.test(x)) x = "+"+x;
    if(!x.startsWith("+")) x = "+"+x;
    return x;
  }).filter(v => /^\+\d{8,15}$/.test(v));

  return unique(cleaned);
}

// Listen for popup request
chrome.runtime.onMessage.addListener((msg, sender, sendResponse)=>{
  if(msg?.type === "scanPhones"){
    try {
      const phones = grabPotentialPhones();
      sendResponse({phones: phones || []});
      return true; // Required for async response in Manifest V3
    } catch (e) {
      console.error("[CONTENT] Error scanning phones:", e);
      sendResponse({phones: []});
      return true;
    }
  }
  return false;
});

