// Shim stub - forwards clicks, mirrors fields for compatibility
(function() {
  'use strict';
  
  // This file provides shim functions for compatibility
  // No-op in unified version as we use consistent event handlers
  console.log('[Builders] Shim loaded');
})();

