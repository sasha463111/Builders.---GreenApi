# Builders - Green API CRM Helper

Chrome Extension for managing WhatsApp conversations via Green API.

## Installation

1. Open Chrome and navigate to `chrome://extensions/`
2. Enable "Developer mode" (toggle in top right)
3. Click "Load unpacked"
4. Select this folder (`builders_production`)
5. The extension icon will appear in your toolbar

## Features

- View WhatsApp chat history by phone number
- Send messages directly from the extension
- Manage multiple Green API accounts
- Auto-scan phone numbers from web pages
- Recent chats sidebar
- Voice message support
- Image, video, and document message support

## First Time Setup

1. Click the extension icon
2. Enter your username and password (provided by your administrator)
3. Your Green API accounts will be loaded automatically
4. Start using the extension!

## Usage

- **Load Chat**: Enter a phone number and click "טען" (Load)
- **Scan Phone**: Click "סרוק" (Scan) to automatically find phone numbers on the current page
- **Send Message**: Type your message and click "שלח" (Send)
- **Manage Accounts**: Click the ⚙️ icon to manage your accounts

## Support

For support, contact your administrator.


