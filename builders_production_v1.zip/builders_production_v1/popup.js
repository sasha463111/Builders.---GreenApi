// Builders - Green API CRM Helper

// Green API base URL
const GREEN_API_BASE = "https://api.greenapi.com";

// Backend API URL for authentication
const BACKEND_AUTH_URL = "https://di-biz.app.n8n.cloud/webhook/b5417ed7-0a1c-4974-b58e-0665eb9da6da";

// Store verified credentials during onboarding
let verifiedUsername = null;
let verifiedPassword = null;

// Verify user credentials with backend
async function verifyUserCredentials(username, password) {
  try {
    const res = await fetchWithRetry(BACKEND_AUTH_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "verifyUser",
        username: username,
        password: password
      })
    });

    if (!res.ok) {
      const errorText = await res.text().catch(() => '');
      console.error("[AUTH] HTTP error:", res.status, res.statusText, errorText);
      return { success: false, error: `שגיאה בשרת: ${res.status}` };
    }

    const data = await res.json();
    console.log("[AUTH] Response:", data);

    // Check if user exists and is active
    // Expected response format: { exists: true, active: true, accounts: [...] } or { success: true, active: true, accounts: [...] }
    if (data.exists === true && data.active === true) {
      return { 
        success: true, 
        data: data,
        accounts: data.accounts || [] // Extract accounts array if present
      };
    } else if (data.success === true && data.active === true) {
      return { 
        success: true, 
        data: data,
        accounts: data.accounts || [] // Extract accounts array if present
      };
    } else if (data.exists === false) {
      return { success: false, error: "משתמש לא נמצא במערכת" };
    } else if (data.active === false) {
      return { success: false, error: "המשתמש לא פעיל" };
    } else {
      return { success: false, error: "פרטים לא תקינים" };
    }
  } catch (e) {
    console.error("[AUTH] Verification error:", e);
    return { success: false, error: `שגיאה בבדיקה: ${e.message}` };
  }
}

// Rate limit handling with exponential backoff
async function fetchWithRetry(url, options = {}, maxRetries = 3) {
  let lastError;
  
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const res = await fetch(url, options);
      
      // Check for rate limit (HTTP 429)
      if (res.status === 429) {
        // Get rate limit headers
        const retryAfter = res.headers.get("Retry-After");
        const rateLimitReset = res.headers.get("X-RateLimit-Reset");
        const rateLimitRemaining = res.headers.get("X-RateLimit-Remaining");
        
        console.warn(`[RATE LIMIT] Attempt ${attempt + 1}/${maxRetries + 1}:`, {
          retryAfter,
          rateLimitReset,
          rateLimitRemaining,
          url
        });
        
        // Calculate wait time: exponential backoff (1s, 2s, 4s) or use Retry-After header
        let waitTime = 1000 * Math.pow(2, attempt); // 1s, 2s, 4s
        if (retryAfter) {
          waitTime = parseInt(retryAfter) * 1000;
        } else if (rateLimitReset) {
          const resetTime = parseInt(rateLimitReset) * 1000;
          const now = Date.now();
          waitTime = Math.max(resetTime - now, 1000);
        }
        
        // Don't retry if we've exceeded max retries
        if (attempt >= maxRetries) {
          throw new Error(`Rate limit exceeded. Please try again later. (HTTP 429)`);
        }
        
        console.log(`[RATE LIMIT] Waiting ${waitTime}ms before retry...`);
        await new Promise(resolve => setTimeout(resolve, waitTime));
        continue; // Retry the request
      }
      
      // For other errors, throw immediately
      if (!res.ok) {
        const errorText = await res.text().catch(() => '');
        throw new Error(`HTTP ${res.status}: ${res.statusText}${errorText ? ' - ' + errorText.substring(0, 100) : ''}`);
      }
      
      // Success - return response
      return res;
      
    } catch (e) {
      lastError = e;
      
      // If it's not a rate limit error and not the last attempt, wait a bit before retry
      if (attempt < maxRetries && !e.message.includes('429')) {
        const waitTime = 500 * (attempt + 1); // 500ms, 1000ms, 1500ms
        console.log(`[RETRY] Waiting ${waitTime}ms before retry (attempt ${attempt + 1})...`);
        await new Promise(resolve => setTimeout(resolve, waitTime));
        continue;
      }
      
      // Last attempt or non-retryable error
      if (attempt >= maxRetries) {
        throw lastError;
      }
    }
  }
  
  throw lastError;
}

// Phone normalization function from N8N code
function normalizePhoneForAPI(raw) {
  if (!raw) return "";
  
  let input = String(raw);
  
  // ניקוי תווים לא רלוונטיים
  input = input.replace(/[^0-9+]/g, "");
  
  // אם מתחיל עם +
  if (input.startsWith("+")) {
    input = input.substring(1);
  }
  
  // אם מתחיל עם 0 → ישראל (ממיר ל-972)
  if (input.startsWith("0")) {
    input = "972" + input.substring(1);
  }
  
  // אם מתחיל עם 972 → השאר
  if (!input.startsWith("972")) {
    // מניח שישראל ברירת מחדל
    input = "972" + input;
  }
  
  return input;
}

// Fetch avatar for a chat
async function fetchChatAvatar(chatId) {
  const { accounts, selectedIndex } = await getState();
  const acc = accounts[selectedIndex];
  if (!acc || !acc.id || !acc.token || !chatId) {
    console.log("[AVATAR] Missing account or chatId:", { hasAcc: !!acc, hasId: !!acc?.id, hasToken: !!acc?.token, chatId });
    return '';
  }

  // Green API endpoint: https://api.greenapi.com/waInstance{{idInstance}}/getAvatar/{{apiTokenInstance}}
  const apiUrl = `${GREEN_API_BASE}/waInstance${acc.id}/getAvatar/${acc.token}`;
  
  try {
    const res = await fetchWithRetry(apiUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chatId: chatId })
    });

    // Check if response is OK
    if (!res.ok) {
      console.log(`[AVATAR] HTTP error for ${chatId}:`, res.status, res.statusText);
      return '';
    }

    // Check content type
    const contentType = res.headers.get("content-type");
    if (!contentType || !contentType.includes("application/json")) {
      console.log(`[AVATAR] Non-JSON response for ${chatId}:`, contentType);
      return '';
    }

    const data = await res.json();
    console.log(`[AVATAR] Response for ${chatId}:`, data);
    
    // Parse avatar URL from response: { "urlAvatar": "...", "available": true }
    if (data && data.urlAvatar) {
      if (data.available === true) {
        return data.urlAvatar;
      } else if (data.available === false) {
        console.log(`[AVATAR] Avatar not available for ${chatId}`);
        return '';
      } else {
        // available field missing, but urlAvatar exists - return it
        return data.urlAvatar;
      }
    }
    
    console.log(`[AVATAR] No avatar URL in response for ${chatId}`);
    return '';
  } catch (e) {
    console.error(`[AVATAR] Error fetching avatar for ${chatId}:`, e);
    return '';
  }
}

// Get chats list from Green API (lastIncoming + lastOutgoing)
async function fetchChatsList() {
  const { accounts, selectedIndex } = await getState();
  const acc = accounts[selectedIndex];
  if (!acc) return [];

  try {
    // Fetch last incoming messages (last 24 hours = 1440 minutes)
    const incomingUrl = `${GREEN_API_BASE}/waInstance${acc.id}/lastIncomingMessages/${acc.token}?minutes=1440`;
    const outgoingUrl = `${GREEN_API_BASE}/waInstance${acc.id}/lastOutgoingMessages/${acc.token}`;
    
    console.log("[CHATS] Fetching incoming messages...");
    const incomingRes = await fetchWithRetry(incomingUrl).catch(e => {
      console.error("[CHATS] Failed to fetch incoming messages:", e);
      return null;
    });
    if (!incomingRes || !incomingRes.ok) {
      console.error("[CHATS] Failed to fetch incoming messages");
      return [];
    }
    
    console.log("[CHATS] Fetching outgoing messages...");
    const outgoingRes = await fetchWithRetry(outgoingUrl).catch(e => {
      console.error("[CHATS] Failed to fetch outgoing messages:", e);
      return null;
    });
    if (!outgoingRes || !outgoingRes.ok) {
      console.error("[CHATS] Failed to fetch outgoing messages");
      return [];
    }
    
    const incomingData = await incomingRes.json();
    const outgoingData = await outgoingRes.json();
    
    console.log("[CHATS] Incoming messages:", incomingData);
    console.log("[CHATS] Outgoing messages:", outgoingData);
    
    // Parse responses - Green API returns { data: [...] } or direct array
    let incomingMessages = [];
    let outgoingMessages = [];
    
    if (Array.isArray(incomingData)) {
      incomingMessages = incomingData;
    } else if (incomingData.data && Array.isArray(incomingData.data)) {
      incomingMessages = incomingData.data;
    } else if (incomingData.messages && Array.isArray(incomingData.messages)) {
      incomingMessages = incomingData.messages;
    }
    
    if (Array.isArray(outgoingData)) {
      outgoingMessages = outgoingData;
    } else if (outgoingData.data && Array.isArray(outgoingData.data)) {
      outgoingMessages = outgoingData.data;
    } else if (outgoingData.messages && Array.isArray(outgoingData.messages)) {
      outgoingMessages = outgoingData.messages;
    }
    
    // Combine both arrays
    const allMessages = [...incomingMessages, ...outgoingMessages];
    console.log("[CHATS] Total messages:", allMessages.length);
    
    if (allMessages.length === 0) {
      return [];
    }
    
    // Group messages by chatId and get last message for each chat
    const chatsMap = new Map();
    let messagesWithoutChatId = 0;
    
    allMessages.forEach((msg, idx) => {
      const chatId = msg.chatId;
      if (!chatId) {
        messagesWithoutChatId++;
        if (idx < 3) console.log("[CHATS] Message without chatId:", { type: msg.type, typeMessage: msg.typeMessage, id: msg.idMessage });
        return;
      }
      
      // Extract phone number from chatId (remove @c.us)
      const phone = chatId.replace('@c.us', '').replace('+', '');
      
      // Get message text
      let text = '';
      if (msg.textMessage) {
        text = msg.textMessage;
      } else if (msg.extendedTextMessage && msg.extendedTextMessage.text) {
        text = msg.extendedTextMessage.text;
      } else if (msg.typeMessage === 'audioMessage') {
        text = '🎵 הודעת קול';
      } else if (msg.typeMessage === 'imageMessage') {
        text = '📷 תמונה';
      } else if (msg.typeMessage === 'videoMessage') {
        text = '🎥 וידאו';
      } else if (msg.typeMessage === 'documentMessage') {
        text = '📄 מסמך';
      } else if (msg.typeMessage === 'quotedMessage') {
        text = msg.extendedTextMessage?.text || '💬 הודעה מצוטטת';
      } else if (msg.typeMessage === 'deletedMessage') {
        text = '🗑️ הודעה נמחקה';
      } else {
        text = '📎 הודעה';
      }
      
      // Get sender name if available (for incoming messages)
      const senderName = msg.senderName || msg.senderContactName || '';
      
      // Get avatar URL if available
      const avatarUrl = msg.avatar || msg.senderAvatar || msg.avatarUrl || '';
      
      // Check if this chat already exists or if this message is newer
      const existingChat = chatsMap.get(chatId);
      if (!existingChat || (msg.timestamp > (existingChat.timestamp || 0))) {
        chatsMap.set(chatId, {
          chatId: chatId,
          phone: phone,
          name: senderName || existingChat?.name || phone,
          avatar: avatarUrl || existingChat?.avatar || '',
          lastMessage: text,
          lastMessageTime: msg.timestamp,
          timestamp: msg.timestamp
        });
      } else if (existingChat) {
        // Update name/avatar if we got better info
        if (senderName && (existingChat.name === existingChat.phone || !existingChat.name)) {
          existingChat.name = senderName;
        }
        if (avatarUrl && !existingChat.avatar) {
          existingChat.avatar = avatarUrl;
        }
      }
    });
    
    if (messagesWithoutChatId > 0) {
      console.log(`[CHATS] Warning: ${messagesWithoutChatId} messages without chatId`);
    }
    
    // Convert map to array and sort by timestamp (newest first)
    const chats = Array.from(chatsMap.values());
    chats.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
    
    console.log("[CHATS] Grouped into", chats.length, "chats");
    console.log("[CHATS] Sample chats:", chats.slice(0, 3));
    
    return chats;
  } catch (e) {
    console.error("Fetch chats error:", e);
    return [];
  }
}

// Render chats list in sidebar
async function renderChatsList() {
  const chatsList = qs("#chatsList");
  if (!chatsList) {
    console.error("[CHATS] chatsList element not found!");
    return;
  }
  
  chatsList.innerHTML = '<div class="chats-loading">טוען צ\'אטים...</div>';
  
  console.log("[CHATS] Starting to fetch chats list...");
  const chats = await fetchChatsList();
  console.log("[CHATS] Received chats:", chats.length, chats);
  
  if (chats.length === 0) {
    chatsList.innerHTML = '<div class="chats-empty">אין צ\'אטים</div>';
    return;
  }
  
  const frag = document.createDocumentFragment();
  
  // Render chats (fetch avatars in parallel if needed)
  for (const chat of chats) {
    const chatItem = document.createElement("div");
    chatItem.className = "chat-item";
    
    // Use phone from chatId or phone field
    const phone = chat.phone || chat.chatId?.replace('@c.us', '').replace('+', '') || '';
    chatItem.dataset.phone = phone;
    chatItem.dataset.chatId = chat.chatId || '';
    
    // Format phone number for display
    const displayPhone = formatPhoneForDisplay(phone);
    const name = chat.name || displayPhone || 'ללא שם';
    const preview = chat.lastMessage || chat.preview || '';
    const time = chat.lastMessageTime || chat.timestamp || '';
    let avatar = chat.avatar || '';
    
    // If no avatar, try to fetch it (but don't wait - render first, update later)
    if (!avatar && chat.chatId) {
      fetchChatAvatar(chat.chatId).then(avatarUrl => {
        if (avatarUrl) {
          const img = chatItem.querySelector('.chat-item-avatar');
          const placeholder = chatItem.querySelector('.chat-item-avatar-placeholder');
          if (img) {
            img.src = avatarUrl;
            img.style.display = 'block';
            if (placeholder) placeholder.style.display = 'none';
          } else if (placeholder) {
            // Create img element
            const newImg = document.createElement('img');
            newImg.src = avatarUrl;
            newImg.alt = name;
            newImg.className = 'chat-item-avatar';
            newImg.onerror = function() {
              this.style.display = 'none';
              if (placeholder) placeholder.style.display = 'flex';
            };
            placeholder.parentNode.insertBefore(newImg, placeholder);
            placeholder.style.display = 'none';
          }
          chat.avatar = avatarUrl; // Cache it
        }
      }).catch(e => console.warn("Avatar fetch failed:", e));
    }
    
    chatItem.innerHTML = `
      <div class="chat-item-header">
        ${avatar ? `<img src="${escapeHtml(avatar)}" alt="${escapeHtml(name)}" class="chat-item-avatar" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';" />` : ''}
        <div class="chat-item-avatar-placeholder" style="${avatar ? 'display:none;' : ''}">${name.charAt(0).toUpperCase()}</div>
        <div class="chat-item-content">
          <div class="chat-item-name">${escapeHtml(name)}</div>
          ${preview ? `<div class="chat-item-preview">${escapeHtml(preview)}</div>` : ''}
          ${time ? `<div class="chat-item-time">${formatTime(time)}</div>` : ''}
        </div>
      </div>
    `;
    
    chatItem.addEventListener("click", () => {
      // Remove active class from all items
      qsa(".chat-item").forEach(item => item.classList.remove("active"));
      // Add active class to clicked item
      chatItem.classList.add("active");
      // Load chat history
      if (phone) {
        qs("#phoneInput").value = phone;
        fetchHistory();
      }
    });
    
    frag.appendChild(chatItem);
  }
  
  chatsList.innerHTML = '';
  chatsList.appendChild(frag);
  console.log("[CHATS] Rendered", chats.length, "chats in sidebar");
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function formatTime(timestamp) {
  if (!timestamp) return '';
  const date = new Date(timestamp * 1000);
  const now = new Date();
  const diff = now - date;
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  
  if (days === 0) {
    return date.toLocaleTimeString('he-IL', { hour: '2-digit', minute: '2-digit' });
  } else if (days === 1) {
    return 'אתמול';
  } else if (days < 7) {
    return `${days} ימים`;
  } else {
    return date.toLocaleDateString('he-IL', { day: '2-digit', month: '2-digit' });
  }
}

function formatPhoneForDisplay(phone) {
  if (!phone) return '';
  // Remove + and format: 972501234567 -> 050-123-4567
  let cleaned = phone.replace(/[^\d]/g, '');
  if (cleaned.startsWith('972')) {
    cleaned = '0' + cleaned.substring(3);
  }
  if (cleaned.length === 10 && cleaned.startsWith('0')) {
    return cleaned.substring(0, 3) + '-' + cleaned.substring(3, 6) + '-' + cleaned.substring(6);
  }
  return phone;
}

const qs = sel => document.querySelector(sel);
const qsa = sel => Array.from(document.querySelectorAll(sel));

// Storage helpers
async function getState() {
  return await chrome.storage.local.get({
    accounts: [],
    selectedIndex: -1
  });
}
async function setState(patch) { await chrome.storage.local.set(patch); }

function showOnboarding() {
  // Reset to step 1
  qs("#obStep1").style.display = "block";
  qs("#obStep2").style.display = "none";
  qs("#obNext").style.display = "block";
  qs("#obSave").style.display = "none";
  
  // Clear all fields
  qs("#obUsername").value = "";
  qs("#obPassword").value = "";
  qs("#obName").value = "";
  qs("#obId").value = "";
  qs("#obToken").value = "";
  
  // Clear messages
  qs("#obError").style.display = "none";
  qs("#obError").textContent = "";
  qs("#obSuccess").style.display = "none";
  qs("#obSuccess").textContent = "";
  
  // Reset verified credentials
  verifiedUsername = null;
  verifiedPassword = null;
  
  qs("#onboardBackdrop").classList.remove("hidden");
  // Focus on username field
  setTimeout(() => qs("#obUsername").focus(), 100);
}
function hideOnboarding() {
  qs("#onboardBackdrop").classList.add("hidden");
}

// Render accounts table inside settings modal
async function renderAccounts() {
  const { accounts, selectedIndex } = await getState();
  const box = qs("#accList");
  box.innerHTML = "";
  if (!accounts || accounts.length === 0) {
    box.classList.add("empty");
    box.textContent = "אין חשבונות שמורים";
    return;
  }
  box.classList.remove("empty");
  accounts.forEach((acc, i) => {
    const isSelected = i === selectedIndex;
    const row = document.createElement("div");
    row.className = "acc-row" + (isSelected ? " selected" : "");
    row.innerHTML = `
      <div class="acc-header">
        <div class="acc-title-section">
          <div class="acc-name">${escapeHtml(acc.name || "חשבון ללא שם")}</div>
          ${isSelected ? '<span class="badge">נבחר</span>' : ''}
        </div>
      </div>
      <div class="acc-details">
        <div class="acc-detail-row">
          <span class="acc-label">ID:</span>
          <span class="acc-value" title="${escapeHtml(acc.id || "—")}">${escapeHtml(acc.id || "—")}</span>
        </div>
        <div class="acc-detail-row">
          <span class="acc-label">TOKEN:</span>
          <span class="acc-value token-value" title="${escapeHtml(acc.token || "")}">${escapeHtml((acc.token || "").substring(0, 40))}${(acc.token || "").length > 40 ? '...' : ''}</span>
        </div>
      </div>
      <div class="acc-actions">
        <button data-i="${i}" class="btn del" title="מחק חשבון" onclick="event.stopPropagation()">מחק</button>
      </div>
    `;
    row.addEventListener("click", async (ev) => {
      if (ev.target.matches(".del") || ev.target.closest(".del")) {
        ev.stopPropagation();
        const idx = parseInt(ev.target.closest(".del").dataset.i, 10);
        const { accounts: arr } = await getState();
        arr.splice(idx, 1);
        await setState({ accounts: arr, selectedIndex: Math.min(arr.length - 1, 0) });
        renderAccounts();
        // Reload chats list after account deletion
        try {
          await renderChatsList();
        } catch (e) {
          console.error("[ACCOUNTS] Error reloading chats after deletion:", e);
        }
      } else if (!ev.target.matches(".del") && !ev.target.closest(".del")) {
        await setState({ selectedIndex: i });
        renderAccounts();
        // Reload chats list after account switch
        try {
          await renderChatsList();
        } catch (e) {
          console.error("[ACCOUNTS] Error reloading chats after switch:", e);
        }
      }
    });
    box.appendChild(row);
  });
}

// Phone scanning (content script sends matches)
function requestScan() {
  return new Promise(async (resolve) => {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id) { 
        console.warn("[SCAN] No active tab found");
        resolve([]); 
        return; 
      }
      
      // Check if content script can be injected (for pages like chrome://, about:, etc.)
      if (tab.url?.startsWith('chrome://') || tab.url?.startsWith('chrome-extension://') || tab.url?.startsWith('about:')) {
        console.warn("[SCAN] Cannot scan on system pages:", tab.url);
        resolve([]);
        return;
      }
      
      // Try to send message with timeout
      const timeout = setTimeout(() => {
        console.warn("[SCAN] Timeout waiting for content script response");
        resolve([]);
      }, 3000);
      
      chrome.tabs.sendMessage(tab.id, { type: "scanPhones" }, (resp) => {
        clearTimeout(timeout);
        if (chrome.runtime.lastError) {
          console.error("[SCAN] Error sending message:", chrome.runtime.lastError.message);
          // Try to inject content script if it's not loaded
          if (chrome.runtime.lastError.message.includes("Could not establish connection")) {
            chrome.scripting.executeScript({
              target: { tabId: tab.id },
              files: ['content.js']
            }).then(() => {
              // Retry after injection
              setTimeout(() => {
                chrome.tabs.sendMessage(tab.id, { type: "scanPhones" }, (retryResp) => {
                  resolve(retryResp?.phones || []);
                });
              }, 100);
            }).catch((e) => {
              console.error("[SCAN] Error injecting content script:", e);
              resolve([]);
            });
            return;
          }
          resolve([]);
          return;
        }
        resolve(resp?.phones || []);
      });
    } catch (e) {
      console.error("[SCAN] Error in requestScan:", e);
      resolve([]);
    }
  });
}

function normalizePhone(raw) {
  if (!raw) return "";
  let s = ("" + raw).replace(/[^\d+]/g, "");
  if (s.startsWith("0")) s = s.replace(/^0/, "+972");
  if (/^972/.test(s)) s = "+" + s;
  if (!s.startsWith("+")) s = "+" + s;
  return s;
}

// Enhanced bubble creation from 3.7
function makeBubble(item) {
  const box = document.createElement("div");
  const fromMe = item.type === "outgoing" || item.fromMe === true;
  box.className = "msg " + (fromMe ? "out" : "in");
  
  const timestamp = item.timestamp || item.messageTimestamp || 0;
  const meta = timestamp ? fmtTime(timestamp) : "";
  
  // Extract text from multiple possible locations (from 3.7 logic)
  let text = item.textMessage || 
             (item.extendedTextMessage && item.extendedTextMessage.text) || 
             (item.extendedTextMessageData && item.extendedTextMessageData.text) || 
             (item.conversation) || 
             "";
  
  // Handle image messages
  if (item.typeMessage === "imageMessage") {
    let inner = '';
    if (item.jpegThumbnail) {
      inner += `<img class="thumb" src="data:image/jpeg;base64,${item.jpegThumbnail}" alt="image" style="max-width:220px;max-height:220px;border-radius:8px;display:block;margin-bottom:4px;" />`;
    }
    if (item.caption || text) {
      inner += `<div>${escapeHtml(item.caption || text)}</div>`;
    }
    if (item.downloadUrl) {
      inner += `<a href="${item.downloadUrl}" target="_blank" rel="noopener" style="display:block;margin-top:6px;text-decoration:none;color:var(--emerald);">📷 פתח תמונה</a>`;
    }
    inner += `<div class="meta">${meta}</div>`;
    box.innerHTML = inner;
  } 
  // Handle audio/voice messages
  else if (item.typeMessage === "audioMessage" || item.typeMessage === "ptt") {
    const audioUrl = item.downloadUrl || item.url || item.mediaUrl || 
                     (item.audioMessage && (item.audioMessage.downloadUrl || item.audioMessage.url));
    const duration = item.seconds || item.duration || item.length || 
                    (item.audioMessage && (item.audioMessage.seconds || item.audioMessage.duration)) || 0;
    const mimeType = item.mimeType || item.audioMessage?.mimeType || 'audio/ogg; codecs=opus';
    
    let inner = '<div class="audio-message">';
    inner += '<div class="audio-icon">🎵</div>';
    inner += '<div class="audio-player-wrapper">';
    
    if (audioUrl) {
      // Create audio player
      const audioId = `audio_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      inner += `<audio id="${audioId}" controls preload="metadata" style="width:100%; max-width:250px; height:32px; outline:none;">`;
      inner += `<source src="${audioUrl}" type="${mimeType}">`;
      inner += '</audio>';
      
      // Add download link if available
      inner += `<a href="${audioUrl}" download class="audio-download" title="הורד הודעה קולית">⬇️</a>`;
    } else {
      inner += '<div style="padding:8px; color:#666; font-size:12px;">🎵 הודעת קול (לא זמינה להורדה)</div>';
    }
    
    if (duration > 0) {
      const minutes = Math.floor(duration / 60);
      const seconds = Math.floor(duration % 60);
      inner += `<div class="audio-duration">${minutes}:${seconds.toString().padStart(2, '0')}</div>`;
    }
    
    inner += '</div>'; // audio-player-wrapper
    inner += '</div>'; // audio-message
    
    if (text) {
      inner += `<div style="margin-top:8px;">${escapeHtml(text)}</div>`;
    }
    
    inner += `<div class="meta">${meta}</div>`;
    box.innerHTML = inner;
  } 
  // Handle video messages
  else if (item.typeMessage === "videoMessage") {
    let inner = '';
    if (item.jpegThumbnail) {
      inner += `<img class="thumb" src="data:image/jpeg;base64,${item.jpegThumbnail}" alt="video" style="max-width:220px;max-height:220px;border-radius:8px;display:block;margin-bottom:4px;" />`;
    }
    inner += '<div>🎥 הודעת וידאו</div>';
    if (item.downloadUrl || item.url) {
      inner += `<a href="${item.downloadUrl || item.url}" target="_blank" rel="noopener" style="display:block;margin-top:6px;text-decoration:none;color:var(--emerald);">🎥 פתח וידאו</a>`;
    }
    if (text) {
      inner += `<div style="margin-top:8px;">${escapeHtml(text)}</div>`;
    }
    inner += `<div class="meta">${meta}</div>`;
    box.innerHTML = inner;
  }
  // Handle document messages
  else if (item.typeMessage === "documentMessage") {
    let inner = '';
    inner += '<div>📄 הודעת מסמך</div>';
    if (item.fileName) {
      inner += `<div style="font-weight:600; margin-top:4px;">${escapeHtml(item.fileName)}</div>`;
    }
    if (item.downloadUrl || item.url) {
      inner += `<a href="${item.downloadUrl || item.url}" target="_blank" rel="noopener" style="display:block;margin-top:6px;text-decoration:none;color:var(--emerald);">📄 הורד מסמך</a>`;
    }
    if (text) {
      inner += `<div style="margin-top:8px;">${escapeHtml(text)}</div>`;
    }
    inner += `<div class="meta">${meta}</div>`;
    box.innerHTML = inner;
  }
  else {
    // Regular text message
    box.innerHTML = `<div>${escapeHtml(text)}</div><div class="meta">${meta}</div>`;
  }
  
  return box;
}

function fmtTime(ts) {
  const d = new Date(typeof ts === 'number' ? (ts < 2e12 ? ts * 1000 : ts) : ts);
  return d.toLocaleString('he-IL', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' });
}

// Fetch chat history directly from Green API
async function fetchHistory() {
  const { accounts, selectedIndex } = await getState();
  const acc = accounts[selectedIndex];
  if (!acc) { showOnboarding(); return; }

  const phoneInput = qs("#phoneInput").value;
  if (!phoneInput) { qs("#phoneInput").focus(); return; }

  // Normalize phone number using the N8N logic
  const normalizedPhone = normalizePhoneForAPI(phoneInput);
  const chatId = `${normalizedPhone}@c.us`;

  // Get messages container
  const messagesContainer = qs("#messages") || qs("#history");
  if (!messagesContainer) {
    console.error("Messages container not found");
    return;
  }

  messagesContainer.innerHTML = '<div style="padding:20px;text-align:center;color:#666;">טוען הודעות...</div>';

  try {
    // Green API endpoint: https://api.greenapi.com/waInstance{id}/getChatHistory/{token}
    const apiUrl = `${GREEN_API_BASE}/waInstance${acc.id}/getChatHistory/${acc.token}`;
    
    console.log("[HISTORY] Fetching from:", apiUrl);
    console.log("[HISTORY] ChatId:", chatId);
    
    const res = await fetchWithRetry(apiUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chatId: chatId,
        count: 100
      })
    }).catch(e => {
      console.error("[HISTORY] Fetch error:", e);
      messagesContainer.innerHTML = `<div style="padding:20px;text-align:center;color:#c00;">שגיאה בטעינת הודעות: ${e.message}</div>`;
      return null;
    });

    if (!res || !res.ok) {
      if (res) {
        const errorText = await res.text().catch(() => '');
        console.error("[HISTORY] HTTP error:", res.status, res.statusText, errorText);
        messagesContainer.innerHTML = `<div style="padding:20px;text-align:center;color:#c00;">שגיאה בטעינת הודעות: ${res.status} ${res.statusText}</div>`;
      }
      return;
    }

    const data = await res.json();
    console.log("[HISTORY] Response:", data);

    // Parse response - Green API returns { data: [...] } or direct array
    let arr = [];
    if (Array.isArray(data)) {
      arr = data;
    } else if (data.data && Array.isArray(data.data)) {
      arr = data.data;
    } else if (data.messages && Array.isArray(data.messages)) {
      arr = data.messages;
    } else if (data.results && Array.isArray(data.results)) {
      arr = data.results;
    }

    if (!Array.isArray(arr) || arr.length === 0) {
      console.log("[HISTORY] No messages found");
      messagesContainer.innerHTML = '<div style="padding:20px;text-align:center;color:#666;">אין הודעות</div>';
      return;
    }

    // Sort by timestamp
    arr.sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0));

    // Create and append bubbles
    messagesContainer.innerHTML = "";
    const frag = document.createDocumentFragment();
    arr.forEach(item => {
      try {
        const bubble = makeBubble(item);
        frag.appendChild(bubble);
      } catch (e) {
        console.error("Error creating bubble:", e, item);
      }
    });

    messagesContainer.appendChild(frag);
    
    // Scroll to bottom
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
    
    // Update active chat in sidebar
    const currentPhone = normalizePhone(phoneInput);
    if (currentPhone) {
      qsa(".chat-item").forEach(item => {
        const itemPhone = item.dataset.phone;
        if (itemPhone && (itemPhone === currentPhone || itemPhone.replace(/[^\d]/g, '') === currentPhone.replace(/[^\d]/g, ''))) {
          item.classList.add("active");
        } else {
          item.classList.remove("active");
        }
      });
    }
  } catch (e) {
    console.error("[HISTORY] Fetch error:", e);
    messagesContainer.innerHTML = `<div style="padding:20px;text-align:center;color:#c00;">שגיאה: ${e.message}</div>`;
  }
}

// Send message directly to Green API
async function sendMessage() {
  const { accounts, selectedIndex } = await getState();
  const acc = accounts[selectedIndex];
  if (!acc) { showOnboarding(); return; }

  const phoneInput = qs("#phoneInput").value;
  const text = qs("#msg").value.trim();
  if (!phoneInput || !text) return;

  // Normalize phone number using the N8N logic
  const normalizedPhone = normalizePhoneForAPI(phoneInput);
  const chatId = `${normalizedPhone}@c.us`;

  try {
    // Green API endpoint: https://api.greenapi.com/waInstance{id}/sendMessage/{token}
    const apiUrl = `${GREEN_API_BASE}/waInstance${acc.id}/sendMessage/${acc.token}`;
    
    console.log("[SEND] Sending to:", apiUrl);
    console.log("[SEND] ChatId:", chatId);
    console.log("[SEND] Message:", text);
    
    const res = await fetchWithRetry(apiUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chatId: chatId,
        message: text
      })
    }).catch(e => {
      console.error("[SEND] Send error:", e);
      alert(`שגיאה בשליחת ההודעה: ${e.message}`);
      return null;
    });

    if (!res || !res.ok) {
      if (res) {
        const errorText = await res.text().catch(() => '');
        console.error("[SEND] HTTP error:", res.status, res.statusText, errorText);
        alert(`שגיאה בשליחת ההודעה: ${res.status} ${res.statusText}`);
      }
      return;
    }

    const data = await res.json();
    console.log("[SEND] Response:", data);

    qs("#msg").value = "";
    
    // Refresh history and chats list after sending
    setTimeout(async () => {
      await fetchHistory();
      await renderChatsList();
    }, 1000);
  } catch (e) {
    console.error("[SEND] Send error:", e);
    alert("שגיאה בשליחת ההודעה: " + e.message);
  }
}

// Init
(async function init() {
  // Wire up buttons
  qs("#btnFetch").addEventListener("click", fetchHistory);
  qs("#btnScan").addEventListener("click", async () => {
    try {
      const found = await requestScan();
      if (found && found.length > 0) { 
        qs("#phoneInput").value = found[0]; 
        fetchHistory(); 
      } else {
        alert("לא נמצאו מספרי טלפון בדף. נסה לסמן מספר ידנית ולבחור 'פתח ב-Builders' בתפריט הקשר.");
      }
    } catch (e) {
      console.error("[SCAN] Error in scan button:", e);
      alert("שגיאה בסריקה: " + e.message);
    }
  });
  qs("#btnSend").addEventListener("click", sendMessage);

  // Auto scan on open - wait a bit for page to be ready
  setTimeout(async () => {
    try {
      const autoFound = await requestScan();
      if (autoFound && autoFound.length > 0) {
        qs("#phoneInput").value = autoFound[0];
        fetchHistory();
      }
    } catch (e) { 
      console.warn("[INIT] Auto scan error:", e); 
    }
  }, 300); // Small delay to ensure page is ready

  // Refresh chats list
  qs("#btnRefreshChats").addEventListener("click", async () => {
    await renderChatsList();
  });

  // Accounts management
  qs("#btnManage").addEventListener("click", async () => {
    qs("#accountsBackdrop").classList.remove("hidden");
    await renderAccounts();
  });
  qs("#accClose").addEventListener("click", () => qs("#accountsBackdrop").classList.add("hidden"));
  qs("#accSave").addEventListener("click", async () => {
    const name = qs("#accName").value.trim();
    const id = qs("#accId").value.trim();
    const token = qs("#accToken").value.trim();
    if (!name || !id || !token) return;
    
    const { accounts } = await getState();
    accounts.push({ name, id, token });
    await setState({ accounts, selectedIndex: accounts.length - 1 });
    qs("#accName").value = qs("#accId").value = qs("#accToken").value = "";
    await renderAccounts();
    // Reload chats list after adding new account
    try {
      await renderChatsList();
    } catch (e) {
      console.error("[ACCOUNTS] Error reloading chats after adding account:", e);
    }
  });

  // Onboarding - Step 1: Authentication
  qs("#obNext").addEventListener("click", async () => {
    const username = qs("#obUsername").value.trim();
    const password = qs("#obPassword").value.trim();
    
    const errorDiv = qs("#obError");
    const successDiv = qs("#obSuccess");
    errorDiv.style.display = "none";
    successDiv.style.display = "none";
    errorDiv.textContent = "";
    successDiv.textContent = "";
    
    // Validate required fields
    if (!username || !password) {
      errorDiv.textContent = "נא להזין שם משתמש וסיסמה";
      errorDiv.style.display = "block";
      return;
    }
    
    // Show loading state
    const nextBtn = qs("#obNext");
    const originalText = nextBtn.textContent;
    nextBtn.textContent = "בודק...";
    nextBtn.disabled = true;
    
    try {
      // Verify user credentials with backend
      const verification = await verifyUserCredentials(username, password);
      
      if (!verification.success) {
        errorDiv.textContent = verification.error || "שגיאה בבדיקת פרטים";
        errorDiv.style.display = "block";
        nextBtn.textContent = originalText;
        nextBtn.disabled = false;
        return;
      }
      
      // User is verified and active
      verifiedUsername = username;
      verifiedPassword = password;
      
      // Check if accounts were provided in the response
      const accountsFromBackend = verification.accounts || [];
      
      if (accountsFromBackend.length > 0) {
        // Accounts provided - save them automatically and skip step 2
        console.log("[ONBOARD] Accounts received from backend:", accountsFromBackend);
        
        // Transform backend accounts to our format
        const transformedAccounts = accountsFromBackend.map((acc, index) => ({
          name: acc.name || `חשבון ${index + 1}`,
          id: acc.id,
          token: acc.token,
          username: username,
          isDefault: acc.isDefault || false
        }));
        
        // Save accounts and set first one as selected (or default if specified)
        // If no account has isDefault, the first one becomes the default
        let defaultIndex = transformedAccounts.findIndex(acc => acc.isDefault === true);
        if (defaultIndex < 0) {
          // No default found - set first account as default
          defaultIndex = 0;
          transformedAccounts[0].isDefault = true;
        }
        const selectedIdx = defaultIndex;
        await setState({ 
          accounts: transformedAccounts, 
          selectedIndex: selectedIdx
        });
        
        // Close onboarding and reload
        hideOnboarding();
        
        // Show success message briefly
        successDiv.textContent = `✅ אימות הצליח! נטענו ${transformedAccounts.length} חשבונות`;
        successDiv.style.display = "block";
        
        // Reload chats list
        setTimeout(async () => {
          try {
            await renderChatsList();
          } catch (e) {
            console.error("[ONBOARD] Error loading chats after account setup:", e);
          }
        }, 500);
        
      } else {
        // No accounts provided - proceed to step 2 for manual entry
        // Hide step 1, show step 2
        qs("#obStep1").style.display = "none";
        qs("#obStep2").style.display = "block";
        qs("#obNext").style.display = "none";
        qs("#obSave").style.display = "block";
        
        successDiv.textContent = "✅ אימות הצליח! נא להזין את פרטי Green API";
        successDiv.style.display = "block";
        
        // Focus on first field of step 2
        setTimeout(() => qs("#obName").focus(), 100);
      }
      
    } catch (e) {
      console.error("[ONBOARD] Error:", e);
      errorDiv.textContent = `שגיאה: ${e.message}`;
      errorDiv.style.display = "block";
    } finally {
      nextBtn.textContent = originalText;
      nextBtn.disabled = false;
    }
  });
  
  // Onboarding - Step 2: Save account details
  qs("#obSave").addEventListener("click", async () => {
    const name = qs("#obName").value.trim() || "Builders Main";
    const id = qs("#obId").value.trim();
    const token = qs("#obToken").value.trim();
    
    const errorDiv = qs("#obError");
    errorDiv.style.display = "none";
    errorDiv.textContent = "";
    
    // Validate required fields
    if (!id || !token) {
      errorDiv.textContent = "נא להזין ID ו-TOKEN";
      errorDiv.style.display = "block";
      return;
    }
    
    // Show loading state
    const saveBtn = qs("#obSave");
    const originalText = saveBtn.textContent;
    saveBtn.textContent = "שומר...";
    saveBtn.disabled = true;
    
    try {
      // Save account with verified username
      await setState({ accounts: [{ name, id, token, username: verifiedUsername }], selectedIndex: 0 });
      hideOnboarding();
    } catch (e) {
      console.error("[ONBOARD] Save error:", e);
      errorDiv.textContent = `שגיאה בשמירה: ${e.message}`;
      errorDiv.style.display = "block";
    } finally {
      saveBtn.textContent = originalText;
      saveBtn.disabled = false;
    }
  });

  // Check if onboarding needed
  const st = await getState();
  if (!st.accounts || st.accounts.length === 0) {
    showOnboarding();
  } else {
    // Load chats list on startup
    console.log("[INIT] Loading chats list on startup...");
    try {
      await renderChatsList();
    } catch (e) {
      console.error("[INIT] Error loading chats list:", e);
    }
  }
})();
