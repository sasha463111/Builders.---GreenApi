// Shim stub - forwards clicks, mirrors fields for compatibility
(function() {
  'use strict';
  // Compatibility layer
})();

